function add(a,b){
    return a+b;
}

export {add};

function sub(a,b){
    return a-b;
}

export default sub;