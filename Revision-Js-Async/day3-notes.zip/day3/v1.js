// class chaistall{
//     getwater(){
//         console.log("get water")
//     }
//     boilwater(){
//         console.log("boil water")
//     }
//     addteapowder(){
//         console.log("add tea")
//     }
//     addmilk(){
//         console.log("add milk")
//     }
//     brewtea(){
//         console.log("brew tea")
//     }

//     makechai(){
//         this.getwater()
//         this.boilwater()
//         this.addteapowder()
//         this.addmilk()
//         this.brewtea()
//     }
//     getchai(){
//         this.makechai()
//     }

// }
// const tea = new chaistall();
// tea.getchai();


// class A{
//     disp(){
//         console.log("A");
//     }
// }

// class B extends A{  
//     // disp(){
//     //     console.log("B");
//     // }
// }

// const obj=new B();
// obj.disp();

// class A{
//     disp(){
//         console.log("A");
//     }
// }

// class B extends A{
//     dispb(){
//         this.disp();
//         console.log("B");
//     }
// }

// class C extends B{
//     dispc(){
//         this.dispb();
//         console.log("C");
//     }
// }

// const obj=new C();
// obj.dispc();


// class A{
//     disp(){
//         console.log("A");
//     }
// }

// class child1 extends A{
//     dispc(){
//         this.disp();
//         console.log("Child1")
//     }
// }


// class child2 extends A{
//     dispc(){
//         this.disp();
//         console.log("Child2")
//     }
// }

// class child3 extends A{
//     dispc(){
//         this.disp();
//         console.log("Child3")
//     }
// }

// const obj = new child1();
// obj.dispc();

// const obj1 = new child2();
// obj1.dispc();

// const obj2 = new child3();
// obj2.dispc();


